#include <graphics.h>
#include <conio.h>
#include <iostream>
#include <cstdlib>
using namespace std;

// Integer Bresenham line algorithm (works in all directions and octants).
void bresenham(int xi, int yi, int xf, int yf) {
    int dx = abs(xf - xi);
    int dy = abs(yf - yi);
    int sx = (xi < xf) ? 1 : -1;
    int sy = (yi < yf) ? 1 : -1;
    int error = dx - dy;

    while (true) {
        putpixel(xi, yi, RED);

        if (xi == xf && yi == yf) {
            break;
        }

        int e2 = 2 * error;

        if (e2 > -dy) {
            error -= dy;
            xi += sx;
        }

        if (e2 < dx) {
            error += dx;
            yi += sy;
        }
    }
}

int main() {
    int gd = DETECT, gm;
    int xi, yi, xf, yf;

    initgraph(&gd, &gm, "C:\\TURBOC3\\BGI");

    cout << "Enter value of xi, yi: ";
    cin >> xi >> yi;

    cout << "\nEnter value of xf, yf: ";
    cin >> xf >> yf;

    setbkcolor(WHITE);
    bresenham(xi, yi, xf, yf);

    getch();
    closegraph();
    return 0;
}
