#include <graphics.h>
#include <conio.h>
#include <iostream>
#include <cmath>
using namespace std;

void dda(int xi, int yi, int xf, int yf) {
    int dx = xf - xi;
    int dy = yf - yi;

    int steps = max(abs(dx), abs(dy));
    float xIncrement, yIncrement;
    float x = xi, y = yi;

    putpixel(xi, yi, RED);

    if (steps == 0) {
        return;
    }

    xIncrement = (float)dx / steps;
    yIncrement = (float)dy / steps;

    for (int i = 0; i < steps; i++) {
        x += xIncrement;
        y += yIncrement;
        putpixel((int)round(x), (int)round(y), RED);
    }
}

int main() {
    int gd = DETECT, gm;
    int xi, yi, xf, yf;

    initgraph(&gd, &gm, "C:\\TURBOC3\\BGI");

    cout << "Enter value of xi, yi: ";
    cin >> xi >> yi;

    cout << "\nEnter value of xf, yf: ";
    cin >> xf >> yf;

    setbkcolor(WHITE);
    dda(xi, yi, xf, yf);

    getch();
    closegraph();
    return 0;
}
